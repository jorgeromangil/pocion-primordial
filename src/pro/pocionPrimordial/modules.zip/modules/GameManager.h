#ifndef GAMEMANAGER_H
#define GAMEMANAGER_H

#include <SFML/Graphics.hpp>
#include <memory>
#include "State.h"

class GameManager
{
public:
    static GameManager *getInstance();
    void changeState(std::unique_ptr<State> newState); // Cambié a unique_ptr para manejo correcto de memoria
    void run();

private:
    GameManager();
    static GameManager *instance;
    std::unique_ptr<State> currentState;
    sf::RenderWindow window;

    void handleInput();
    void update(float deltaTime);
    void render();
};

#endif
