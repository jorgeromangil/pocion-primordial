#include "KeyboardMovement.h"
#include <SFML/Window/Keyboard.hpp>

void KeyboardMovement::move(sf::Sprite &sprite, float deltaTime)
{
    float speed = 200.0f * deltaTime; // Velocidad ajustada con deltaTime

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
    {
        sprite.move(0, -speed);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
    {
        sprite.move(0, speed);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
    {
        sprite.move(-speed, 0);
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
    {
        sprite.move(speed, 0);
    }
}
