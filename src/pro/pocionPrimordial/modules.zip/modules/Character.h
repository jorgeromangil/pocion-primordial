#ifndef CHARACTER_H
#define CHARACTER_H

#include <SFML/Graphics.hpp>
#include "IMovementStrategy.h"

class Character
{
private:
    sf::Sprite sprite;
    sf::Texture texture;
    IMovementStrategy *movementStrategy;

public:
    Character();
    void setMovementStrategy(IMovementStrategy *strategy);
    void move(float deltaTime);
    void draw(sf::RenderWindow &window);
};

#endif
