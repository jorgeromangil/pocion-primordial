#include "PauseState.h"
#include "GameManager.h"
#include "PlayingState.h"
#include <SFML/Graphics.hpp>
#include <iostream>

void PauseState::handleInput(sf::RenderWindow &window)
{
    sf::Event event;
    while (window.pollEvent(event))
    {
        if (event.type == sf::Event::Closed)
            window.close();

        if (event.type == sf::Event::KeyPressed)
        {
            if (event.key.code == sf::Keyboard::Escape)
            {
                std::cout << "Reanudando juego..." << std::endl;
                GameManager::getInstance()->changeState(std::make_unique<PlayingState>());
            }
        }
    }
}

void PauseState::update(float /*deltaTime*/) {}

void PauseState::render(sf::RenderWindow &window)
{
    window.clear();

    // Opcional: Dibujar un rectángulo semitransparente para indicar que el juego está en pausa
    sf::RectangleShape overlay(sf::Vector2f(window.getSize().x, window.getSize().y));
    overlay.setFillColor(sf::Color(0, 0, 0, 150)); // Negro semitransparente
    window.draw(overlay);

    // Opcional: Dibujar un rectángulo o cualquier otra forma para indicar pausa
    sf::RectangleShape pauseBox(sf::Vector2f(200, 100));
    pauseBox.setFillColor(sf::Color::White);
    pauseBox.setPosition((window.getSize().x - 200) / 2, (window.getSize().y - 100) / 2);
    window.draw(pauseBox);

    window.display();
}