#ifndef IMOVEMENTSTRATEGY_H
#define IMOVEMENTSTRATEGY_H

#include <SFML/Graphics.hpp>

class IMovementStrategy
{
public:
    virtual void move(sf::Sprite &sprite, float deltaTime) = 0;
};

#endif
