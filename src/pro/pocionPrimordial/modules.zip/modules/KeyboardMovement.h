#ifndef KEYBOARDMOVEMENT_H
#define KEYBOARDMOVEMENT_H

#include "IMovementStrategy.h"

class KeyboardMovement : public IMovementStrategy
{
public:
    void move(sf::Sprite &sprite, float deltaTime) override;
};

#endif
