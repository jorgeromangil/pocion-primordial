#include "Character.h"
#include <iostream>

Character::Character()
{
    if (!texture.loadFromFile("resources/sprites.png"))
    {
        std::cerr << "Error cargando la imagen sprites.png" << std::endl;
    }
    sprite.setTexture(texture);
    sprite.setTextureRect(sf::IntRect(0, 0, 75, 75));
    sprite.setPosition(320, 240); // Centro de la pantalla
}

void Character::setMovementStrategy(IMovementStrategy *strategy)
{
    movementStrategy = strategy;
}

void Character::move(float deltaTime)
{
    if (movementStrategy)
    {
        movementStrategy->move(sprite, deltaTime);
    }
}

void Character::draw(sf::RenderWindow &window)
{
    window.draw(sprite);
}
