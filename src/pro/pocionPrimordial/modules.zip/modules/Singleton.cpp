// Singleton.cpp

#include "Singleton.h"
#include <iostream>

void Singleton::doSomething() {
    std::cout << "Haciendo algo en Singleton..." << std::endl;
}

