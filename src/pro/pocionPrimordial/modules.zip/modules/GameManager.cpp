#include "GameManager.h"
#include "MenuState.h"

GameManager *GameManager::instance = nullptr;

GameManager::GameManager() : window(sf::VideoMode(640, 480), "Dungeon Survivors")
{
    currentState = std::make_unique<MenuState>(); // Inicializa con un estado por defecto
}

GameManager *GameManager::getInstance()
{
    if (!instance)
        instance = new GameManager();
    return instance;
}

void GameManager::changeState(std::unique_ptr<State> newState)
{
    if (newState)
    {
        currentState = std::move(newState); // Cambiar el estado actual de manera segura
    }
}

void GameManager::run()
{
    sf::Clock clock;

    while (window.isOpen())
    {
        float deltaTime = clock.restart().asSeconds();

        handleInput();
        update(deltaTime);
        render();
    }
}

void GameManager::handleInput()
{
    currentState->handleInput(window); // Procesar entradas del estado actual
}

void GameManager::update(float deltaTime)
{
    currentState->update(deltaTime); // Actualizar el estado actual
}

void GameManager::render()
{
    window.clear();               // Limpiar ventana antes de renderizar
    currentState->render(window); // Renderizar el estado actual
    window.display();             // Mostrar lo renderizado
}
