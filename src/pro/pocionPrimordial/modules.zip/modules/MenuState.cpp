#include "MenuState.h"
#include "GameManager.h"
#include "PlayingState.h"
#include <SFML/Window/Event.hpp>
#include <iostream>

void MenuState::handleInput(sf::RenderWindow &window)
{
    sf::Event event;
    while (window.pollEvent(event))
    {
        if (event.type == sf::Event::Closed)
            window.close();

        if (event.type == sf::Event::KeyPressed)
        {
            if (event.key.code == sf::Keyboard::Enter)
            {
                std::cout << "Iniciando juego..." << std::endl;
                GameManager::getInstance()->changeState(std::make_unique<PlayingState>()); // Cambiado a std::make_unique
            }
        }
    }
}

void MenuState::update(float /*deltaTime*/) {}

void MenuState::render(sf::RenderWindow &window)
{
    window.clear();
    // Renderiza elementos del menú aquí
    window.display();
}