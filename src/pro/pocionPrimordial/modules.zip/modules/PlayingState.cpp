#include "PlayingState.h"
#include "GameManager.h"
#include "PauseState.h"
#include "KeyboardMovement.h" // Asegúrate de incluir este archivo
#include <SFML/Window/Event.hpp>
#include <iostream>

PlayingState::PlayingState()
{
    player.setMovementStrategy(std::make_unique<KeyboardMovement>().release()); // Cambiado a release para pasar un puntero crudo
}

void PlayingState::handleInput(sf::RenderWindow &window)
{
    sf::Event event;
    while (window.pollEvent(event))
    {
        if (event.type == sf::Event::Closed)
            window.close();

        if (event.type == sf::Event::KeyPressed)
        {
            if (event.key.code == sf::Keyboard::Escape)
            {
                std::cout << "Pausa activada" << std::endl;
                GameManager::getInstance()->changeState(std::make_unique<PauseState>()); // Cambiado a std::make_unique
            }
        }
    }
}

void PlayingState::update(float deltaTime)
{
    player.move(deltaTime);
}

void PlayingState::render(sf::RenderWindow &window)
{
    window.clear();
    player.draw(window);
    window.display();
}