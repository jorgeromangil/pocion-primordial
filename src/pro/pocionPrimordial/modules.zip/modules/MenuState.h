#ifndef MENUSTATE_H
#define MENUSTATE_H

#include "State.h"
#include "GameManager.h"

class MenuState : public State
{
public:
    void handleInput(sf::RenderWindow &window) override;
    void update(float deltaTime) override;
    void render(sf::RenderWindow &window) override;
};

#endif
